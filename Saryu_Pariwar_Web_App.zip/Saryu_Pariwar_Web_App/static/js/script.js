$('.gallery-slider').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    autoplay:true,
    autoplayTimeout:1000,
    autoplayHoverPause:true,
    responsive:{
        0:{
            items:1
        },
        560:{
            items:2
        },
        768:{
            items:3
        },
        991:{
            items: 3
        }
    }
});
$('.testimonial-slider').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    autoplay:true,
    autoplayTimeout:1000,
    autoplayHoverPause:true,
    responsive:{
        0:{
            items:1
        },
        560:{
            items:2
        },
        768:{
            items:3
        }
    }
});
// const toggleButton = document.getElementById('toggleButton');
// const hiddenDiv = document.getElementById('hiddenDiv');
// toggleButton.addEventListener('click', function() {
//     hiddenDiv.classList.toggle('hidden');
//     hiddenDiv.classList.toggle('opacity-0');
//     if (!hiddenDiv.classList.contains('hidden')) {
//         hiddenDiv.classList.add('opacity-100')
//     }
// });

$("#menu").metisMenu();
$("#btn").click(function(){
    $(".wrapper").toggleClass("active");
    $(".sidebar_wrapper .toggle-icon").removeClass("ms-auto");
    $(".sidebar_wrapper .toggle-icon").addClass("m-auto");
});