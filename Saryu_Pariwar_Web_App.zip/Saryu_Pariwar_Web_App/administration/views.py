# Python Imports
import json
from django.db.models import Q
from django.contrib import messages
from django.http import JsonResponse
from django.utils.timezone import now
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout

# Local Imports
from . import models
from .forms import RegistrationForm

def homepage(request):
    if request.user.is_authenticated:
        if request.user.is_superuser:
            return redirect('/admin/')
        else:
            return redirect('/dashboard/')
    if request.method == 'POST':
        # if request.POST.get('form_type') == 'Registration':
        return registration_page(request)
    else:
        samaj_gallery_images = models.SamajGallery.objects.all()
        promotions = models.Promotion.objects.filter(
            Q(expires_at__gte=now().date()) | Q(expires_at__isnull=True)
        )
        testimonials = models.Testimonial.objects.all().order_by('-updated_at')[:4]
        # print(promotions.count())
        samaj_event_objs = models.SamajEvent.objects.all().order_by('-date_of_event')[:4]
        samaj_events = [
            {
                'title': samaj_event.title,
                'date_of_event': samaj_event.date_of_event.strftime('%d %b, %Y')
            } for samaj_event in samaj_event_objs
        ]
        return render(request, 'index.html', {'samaj_gallery_images': samaj_gallery_images, 'samaj_events': samaj_events, 'promotions': promotions, 'testimonials': testimonials})


# def registration_page(request):
#     if request.user.is_authenticated:
#         if request.user.is_superuser:
#             return redirect('/admin/')
#         else:
#             return redirect('/dashboard/')
#     # print(request.method)
#     if request.method == 'POST':
#         form = RegistrationForm(request.POST, request.FILES)
#         if form.is_valid():
#             user = form.save(commit=False)
#             user.save()
#             print('form saved')
#             messages.success(request, "Account created successfully.")
#             return redirect('/')
#         else:
#             print(form.errors)
#             messages.error(request, form.errors)
#             return redirect('/')

#     return redirect('/')

from django.shortcuts import render, redirect
from django.contrib import messages
import qrcode
import io
import base64

from django.shortcuts import render, redirect
from django.contrib import messages

def registration_page(request):
    if request.user.is_authenticated:
        if request.user.is_superuser:
            return redirect('/admin/')
        else:
            return redirect('/dashboard/')

    if request.method == 'POST':
        form = RegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save(commit=False)
            user.save()
            print('form saved')

            # Use existing QR image file instead of generating dynamically
            # Example: stored in static/images/qr_code.jpeg
            qr_image_url = '/static/images/qr_code.jpeg'

            return render(request, 'qr_page.html', {
                'qr_code_url': qr_image_url,
                'username': user.username
            })

        else:
            print(form.errors)
            messages.error(request, form.errors)
            return redirect('/dashboard/')

    return redirect('/dashboard/')


def send_otp(request):
    if request.user.is_authenticated:
        if request.user.is_superuser:
            return redirect('/admin/')
        else:
            return redirect('/dashboard/')
    if request.method == 'POST':
        phone_number = json.loads(request.body).get('phone_number')
        user = models.CustomUser.objects.filter(phone_number=phone_number)
        if user.exists():
            user = user.first()
            otp = models.UserOTP.generate_otp(user)
            print(f'OTP for login is: {otp.otp_code}')
            return JsonResponse({'success': True, 'message': 'OTP sent successfully'}, status=200)
        else:
            return JsonResponse({'success': False, 'message':'User not found'}, status=404)
    return redirect('/')


def verify_otp(request):
    if request.user.is_authenticated:
        if request.user.is_superuser:
            return redirect('/admin/')
        else:
            return redirect('/dashboard/')
    if request.method == 'POST':
        phone_number = request.POST.get('otp_phone_number')
        otp = request.POST.get('otp')
        user = models.CustomUser.objects.filter(phone_number=phone_number)
        if user.exists():
            user = user.first()
            user_otp_obj = models.UserOTP.objects.filter(
                user=user,
                otp_code=otp
            )
            if user_otp_obj.exists() and not user_otp_obj.latest('expires_at').is_expired():
                login(request, user)
                user_otp_obj.delete()
                # print('User logged in successfully.')
                return redirect('/dashboard/')
            else:
                # print('Invalid or expired OTP.')
                messages.error(request, "Invalid or expired OTP.")
        else:
            # print('User not found for OTP verification.')
            messages.error(request, "User not found for OTP verification.")
            # print('User not Found')

    return redirect('/')


def logout_user(request):
    logout(request)
    messages.success(request, 'Logged out successfully.')
    return redirect('/')
