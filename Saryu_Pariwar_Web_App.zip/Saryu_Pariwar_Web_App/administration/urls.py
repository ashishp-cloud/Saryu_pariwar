# Python Imports
from django.urls import path
from django.contrib.auth.decorators import login_required

# Local Imports
from . import views

urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('send_otp/', views.send_otp, name='send_otp'),
    path('verify_otp/', views.verify_otp, name='verify_otp'),
    path('logout/', login_required(views.logout_user), name='logout_user')
]
