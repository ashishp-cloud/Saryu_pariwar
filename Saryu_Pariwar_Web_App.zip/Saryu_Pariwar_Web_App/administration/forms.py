from django import forms
from .models import CustomUser

class RegistrationForm(forms.ModelForm):
    form_type = forms.CharField(required=False)
    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'father_name', 'native_village', 'district', 'tehsil', 'current_address', 'phone_number', 'business_address', 'business_phone_number', 'profile_pic']
    
    def clean(self):
        errors = []
        cleaned_data = super().clean()
        phone_number = cleaned_data.get("phone_number")
        business_phone_number = cleaned_data.get("business_phone_number")
        # if not phone_number or not str(phone_number).isdigit() or len(phone_number) != 10:
        #     errors.append('Invalid Phone: Phone number must be a 10 digit number')
        # if not str(business_phone_number).isdigit() or len(business_phone_number) != 10:
        #     errors.append('Invalid Business Phone: Business phone number must be a 10 digit number')
        if len(errors) != 0:
            raise forms.ValidationError(str(errors))
        
        return cleaned_data
