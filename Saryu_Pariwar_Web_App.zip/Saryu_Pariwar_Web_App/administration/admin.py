import datetime
from . import models
from django import forms
from django.contrib import admin


class UserAdmin(admin.ModelAdmin):
    fields =  ('first_name', 'last_name', 'native_village', 'district', 'tehsil', 'current_address', 'phone_number', 'business_address', 'business_phone_number', 'profile_pic')
    # readonly_fields = ('created_at', 'updated_at')

class SamajEventForm(forms.ModelForm):
    class Meta:
        model = models.SamajEvent
        fields = '__all__'
        widgets = {
            'date_of_event': forms.DateTimeInput(attrs={'type': 'datetime-local'})
        }

    def clean_date_of_event(self):
        date_of_event = self.cleaned_data.get('date_of_event')
        if isinstance(date_of_event, str):
            date_of_event = datetime.datetime.strptime(date_of_event, '%Y-%m-%dT%H:%M')
        return date_of_event

class SamajEventAdmin(admin.ModelAdmin):
    fields = ('title', 'date_of_event', 'remarks', 'created_at', 'updated_at')
    readonly_fields = ('created_at', 'updated_at')
    # form = SamajEventForm

    # def formatted_date_of_event(self, obj):
        # return obj.date_of_event.strftime('%I:%M %p')  # 12-hour format with AM/PM

    # formatted_date_of_event.short_description = 'Date of Event (12-hour format)'


class SamajGalleryAdmin(admin.ModelAdmin):
    fields = ('title', 'image', 'remarks', 'created_at', 'updated_at')
    readonly_fields = ('created_at', 'updated_at')
    # fieldsets = (
    #     (None, {
    #         'fields': ('title', 'image', 'remarks')
    #     }),
    #     ('Timestamps', {
    #         'fields': ('created_at', 'updated_at'),
    #         'classes': ('collapse',),
    #     }),
    # )

admin.site.register(models.CustomUser, UserAdmin)
admin.site.register(models.SamajGallery, SamajGalleryAdmin)
admin.site.register(models.SamajEvent, SamajEventAdmin)
# admin.site.register(models.UserOTP)
admin.site.register(models.Promotion)
admin.site.register(models.Testimonial)
# admin.site.register(UserOTP)