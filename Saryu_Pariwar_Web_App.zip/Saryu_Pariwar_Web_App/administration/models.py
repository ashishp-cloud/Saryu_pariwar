# Python Imports
import string
import random
from django.db import models
from django.utils import timezone
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.contrib.auth.models import AbstractUser, BaseUserManager

# Local Imports
from .mixins import FileDeleteMixin
from .utils import generate_otp_code

class DateFields(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


def validate_phone_number(value):
    if not isinstance(value, int):
        raise ValidationError('Phone must be an integer.')
    if len(str(abs(value))) != 10:
        raise ValidationError('Phone number must be exactly 10 digits.')


class CustomUserManager(BaseUserManager):
    def create_user(self, username, email=None, password=None, **extra_fields):
        if not username:
            raise ValueError("The Username field must be set")
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)

        user = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email=None, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(username, email, password, **extra_fields)


class CustomUser(AbstractUser):
    # head_of_the_family_name = models.CharField(max_length=200)
    first_name = models.CharField(max_length=200, null=True)
    last_name = models.CharField(max_length=200, null=True)
    father_name = models.CharField(max_length=200, null=True)
    # mother_name = models.CharField(max_length=200)
    # date_of_birth = models.DateField()
    # time_of_birth = models.TimeField(blank=True, null=True)
    # blood_group = models.CharField(max_length=5, blank=True, null=True)
    # gotra = models.CharField(max_length=100, blank=True, null=True)
    native_village = models.CharField(max_length=500, blank=True, null=True)
    district = models.CharField(max_length=500, null=True)
    tehsil = models.CharField(max_length=500, blank=True, null=True)
    current_address =  models.TextField(null=True)
    phone_number = models.CharField(max_length=10, unique=True, null=True)
    business_address = models.TextField(blank=True, null=True)
    business_phone_number = models.CharField(max_length=10, blank=True, null=True)
    profile_pic = models.ImageField(upload_to='user_profile_pics', null=True)

    objects = CustomUserManager()

    def __str__(self):
        return self.show_username()
    
    def show_username(self):
        return f'{self.first_name} {self.last_name}' if self.first_name and self.last_name else self.username
    
    def generate_unique_username(self):
        username_base = f"{self.first_name.lower()}_{self.phone_number}"
        username = username_base
        
        while CustomUser.objects.filter(username=username).exists():
            random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=4))
            username = f"{username_base}_{random_suffix}"

        return username
    
    def save(self, *args, **kwargs):
        if not self.username:
            self.username = self.generate_unique_username()
        super().save(*args, **kwargs)


class UserOTP(models.Model):
    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    otp_code = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    def is_expired(self):
        return timezone.now() > self.expires_at

    @staticmethod
    def generate_otp(user):
        otp_code = '123456'
        # otp_code = generate_otp_code()
        expires_at = timezone.now() + timezone.timedelta(minutes=5)
        otp = UserOTP.objects.create(
            user=user,
            otp_code=otp_code,
            expires_at=expires_at
        )
        return otp


class SamajGallery(DateFields):
    title = models.CharField(max_length=100, blank=True, null=True)
    image = models.ImageField(upload_to='samaj_gallery')
    remarks = models.CharField(max_length=200, blank=True, null=True)
    
    class Meta:
        verbose_name = 'Samaj Gallery'
        verbose_name_plural = 'Samaj Gallery'

    def __str__(self):
        return self.title

    # def save(self, *args, **kwargs):
    #     if not self.title:
    #         self.title = f'Image {self.pk}'
    #     super().save(*args, **kwargs)


class SamajEvent(DateFields):
    title = models.CharField(max_length=100)
    date_of_event = models.DateField()
    remarks = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        verbose_name = 'Samaj Event'
        verbose_name_plural = 'Samaj Events'

    def __str__(self):
        return self.title
    

class Promotion(DateFields):
    banner = models.ImageField(upload_to='promotions')
    advertiser_name = models.CharField(max_length=500)
    advertiser_email = models.EmailField(blank=True, null=True)
    advertiser_phone = models.CharField(max_length=10, blank=True, null=True)
    expires_at = models.DateField(blank=True, null=True)

    class Meta:
        verbose_name = 'Promotions'
        verbose_name_plural = 'Promotions'

    def __str__(self):
        return self.advertiser_name


class Testimonial(DateFields):
    made_by = models.CharField(max_length=500)
    testimony = models.TextField()
    image = models.ImageField(upload_to='testimony_images')

    class Meta:
        verbose_name = 'Testimonials'
        verbose_name_plural = 'Testimonials'

    def __str__(self):
        return self.made_by
